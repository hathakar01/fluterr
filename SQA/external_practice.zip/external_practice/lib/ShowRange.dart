import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Range Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: MyHomePage(title: 'Range Demo'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  MyHomePage({Key? key, required this.title}) : super(key: key);

  final String title;

  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  TextEditingController _startController = TextEditingController();
  TextEditingController _endController = TextEditingController();
  List<int> _rangeNumbers = [];

  void _showRange() {
    int start = int.tryParse(_startController.text) ?? 0;
    int end = int.tryParse(_endController.text) ?? 0;

    setState(() {
      _rangeNumbers = List<int>.generate(end - start + 1, (index) => start + index);
    });
  }

  @override
  void dispose() {
    _startController.dispose();
    _endController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: <Widget>[
            TextField(
              controller: _startController,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(
                labelText: 'Starting Number',
              ),
            ),
            SizedBox(height: 16),
            TextField(
              controller: _endController,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(
                labelText: 'Ending Number',
              ),
            ),
            SizedBox(height: 16),
            ElevatedButton(
              onPressed: _showRange,
              child: Text('Show Range'),
            ),
            SizedBox(height: 16),
            Expanded(
              child: ListView.builder(
                itemCount: _rangeNumbers.length,
                itemBuilder: (context, index) {
                  return ListTile(
                    title: Text(_rangeNumbers[index].toString()),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
