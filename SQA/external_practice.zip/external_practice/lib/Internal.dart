import 'package:flutter/material.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Student Information',
      home: StudentForm(),
    );
  }
}

class StudentForm extends StatefulWidget {
  @override
  _StudentFormState createState() => _StudentFormState();
}

class _StudentFormState extends State<StudentForm> {
  final _formKey = GlobalKey<FormState>();
  TextEditingController _idController = TextEditingController();
  TextEditingController _dobController = TextEditingController();
  bool _skill1 = false;
  bool _skill2 = false;
  bool _skill3 = false;
  String skills = "";
  //String _displayText = '';

  Future<void> _selectDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
        context: context,
        initialDate: DateTime.now(),
        firstDate: DateTime(1900),
        lastDate: DateTime(2025));
    if (picked != null) {
      setState(() {
        _dobController.text = picked.toString().substring(0, 10);
      });
    }
  }

  /*void _showInfo() {
    String skills = '';
    if (_skill1) skills += 'flutter, ';
    if (_skill2) skills += 'java, ';
    if (_skill3) skills += '.NET, ';
    /*setState(() {
      _displayText = 'ID: ${_idController.text}\nDate of Birth: ${_dobController.text}\nSkills: $skills';
    });*/
  }*/
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Student Information"),
      ),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              TextFormField(
                controller: _idController,
                decoration: InputDecoration(labelText: "Student ID"),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return "Please enter a student ID";
                  }
                  return null;
                },
              ),
              SizedBox(height: 16.0),
              TextFormField(
                controller: _dobController,
                decoration: InputDecoration(labelText: "Date of Birth"),
                onTap: () {
                  _selectDate(context);
                },
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return "Please select a date of birth";
                  }
                  return null;
                },
              ),
              SizedBox(height: 16.0),

              CheckboxListTile(
                  title: Text('flutter'),
                  value: _skill1,
                  onChanged: (newValue) {
                    setState(() {
                      _skill1 = newValue!;
                    });
                  }),
              CheckboxListTile(
                  title: Text("java"),
                  value: _skill2,
                  onChanged: (newValue) {
                    setState(() {
                      _skill2 = newValue!;
                    });
                  }),
              CheckboxListTile(
                  title: Text('.NET'),
                  value: _skill3,
                  onChanged: (newValue) {
                    setState(() {
                      _skill3 = newValue!;
                    });
                  }),
              SizedBox(height: 16.0),
              ElevatedButton(
                onPressed: (){
                  Navigator.push(context, MaterialPageRoute(builder: (context) => NextScreen(_idController.text,_dobController.text,_skill1.toString(),_skill2.toString(),_skill3.toString(),skills.toString())),);
                },
                child: Text('Show'),
              ),
              SizedBox(height: 16.0),
            ],
          ),
        ),
      ),
    );
  }
}

class NextScreen extends StatelessWidget{
  String _idController = "";
  String _dobController = "";
  String _skill1 = "";
  String _skill2 = "";
  String _skill3 = "";
  String skills ="";

  NextScreen(this._idController, this._dobController, this._skill1, this._skill2,this._skill3,this.skills);

  @override
  Widget build(BuildContext context) {
    Container c1 = Container(
      color: Colors.indigo,
      padding: EdgeInsets.all(20.0),
      child: Table(
        children: [
          TableRow(
              children: [
                Text(_idController),
                Text(_dobController),
                Text(_skill1),
                Text(_skill2),
                Text(_skill3),
                Text(skills),
              ]
          )
        ],
      ),
    );
    AppBar ab = AppBar(title: const Text("Student Information"));
    Scaffold s1 = Scaffold(
      appBar: ab,
      body: c1,
    );
    return s1;
  }
}