import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: const MyHomePage(title: 'Flutter Demo Home Page'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key, required this.title});

  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  String uname = "Harshal";
  String pass = "eee";
  final unameController = TextEditingController();
  final passController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Login Page "),
      ),
      body: Center(
        child: Container(
          height: 400,
          width: 300,
          child: Column(
            children: [
              Text("Login Here"),
              TextField(
                controller: unameController,
                decoration: InputDecoration(
                  prefixIcon: Icon(
                    Icons.mobile_friendly,
                  ),
                  hintText: "Username",
                ),
              ),
              TextField(
                controller: passController,
                decoration: InputDecoration(
                  prefixIcon: Icon(
                    Icons.keyboard,
                  ),
                  hintText: "PassWord",
                ),
              ),
              Container(
                  alignment: Alignment.centerRight,
                  child: GestureDetector(
                    onTap: () {},
                    child: Text("Create Account?"),
                  )),
              ElevatedButton(
                child: Text("Submit"),
                onPressed: () {
                  String un = unameController.text;
                  String password = passController.text;
                  if (un == uname && password == pass) {
                    Navigator.push(context,
                        MaterialPageRoute(builder: (context) => weclcome()));
                  } else {
                    Text("Invalid Username or Password");
                    unameController.text = "";
                    passController.text = "";
                  }
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class weclcome extends StatefulWidget {
  WelcomePage createState() => WelcomePage();
}

class WelcomePage extends State<weclcome> {
  String _selectedOption = '';

  @override
  Widget build(BuildContext context) {
    TextEditingController id = TextEditingController();
    TextEditingController n = TextEditingController();
    TextEditingController age = TextEditingController();
    Row r1 = Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Container(
          padding: EdgeInsets.symmetric(horizontal: 16),
          width: 800,
          margin: EdgeInsets.symmetric(vertical: 15),
          child: TextField(
            controller: n,
            decoration: InputDecoration(hintText: "enter your Name "),
          ),
        ),
      ],
    );
    Row r2 = Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Container(
          padding: EdgeInsets.symmetric(horizontal: 16),
          width: 800,
          margin: EdgeInsets.symmetric(vertical: 15),
          child: TextField(
            controller: id,
            decoration: InputDecoration(hintText: "enter your id "),
          ),
        ),
      ],
    );
    Row r3 = Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Container(
          padding: EdgeInsets.symmetric(horizontal: 16),
          width: 800,
          margin: EdgeInsets.symmetric(vertical: 15),
          child: TextField(
            controller: age,
            decoration: InputDecoration(hintText: "enter your age "),
          ),
        ),
      ],
    );
    Column r4 = Column(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        Container(
          child: RadioListTile<String>(
            title: Text('male'),
            value: 'male',
            groupValue: _selectedOption,
            activeColor: Colors.deepPurpleAccent,
            onChanged: (value) {
              setState(() {
                _selectedOption = value!;
              });
            },
          ),
        ),
        Container(
          child: RadioListTile<String>(
            title: Text('female'),
            value: 'female',
            groupValue: _selectedOption,
            activeColor: Colors.deepPurpleAccent,
            onChanged: (value) {
              setState(() {
                _selectedOption = value!;
              });
            },
          ),
        ),
      ],
    );
    Row r5 = Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Container(
            child: ElevatedButton(
          onPressed: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                  builder: (context) => NexNextScreen(n.text, age.text, id.text, _selectedOption)),
            );
          },
          child: Text("submit"),
        )
        ),
      ],
    );

    Column c1 = Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [r1, r2, r3, r4, r5]);

    Scaffold S1 = Scaffold(
      body: c1,
    );
    return S1;
  }
}

class NexNextScreen extends StatelessWidget {
  String n = "";
  String id = "";
  String age = "";
  String _selectedOption = "";
  NexNextScreen(this.n, this.age, this.id, this._selectedOption);
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    Container c1 = Container(
      color: Colors.white,
      padding: EdgeInsets.all(20.0),
      child: Table(
        border: TableBorder.all(color: Colors.black),
        children: [
          TableRow(children: [
            Text('id'),
            Text('name'),
            Text('age'),
            Text('gender'),
          ]),
          TableRow(children: [
            Text(id),
            Text(n),
            Text(age),
            Text(_selectedOption),
          ])
        ],
      ),
    );
    Scaffold s1 = Scaffold(
      body: c1,
    );
    return s1;
  }
}
